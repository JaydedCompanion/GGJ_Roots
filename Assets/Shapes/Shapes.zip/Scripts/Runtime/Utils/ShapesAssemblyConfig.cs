﻿// Shapes © Freya Holmér - https://twitter.com/FreyaHolmer/
// Website & Documentation - https://acegikmo.com/shapes/

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo( "ShapesEditor" )]