﻿using System;

// Shapes © Freya Holmér - https://twitter.com/FreyaHolmer/
// Website & Documentation - https://acegikmo.com/shapes/
namespace Shapes {

	[AttributeUsage( AttributeTargets.Field )]
	public class DestroyOnAssemblyReload : Attribute {
	}

}