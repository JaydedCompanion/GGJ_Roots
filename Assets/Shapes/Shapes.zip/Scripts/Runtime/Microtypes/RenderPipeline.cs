﻿// Shapes © Freya Holmér - https://twitter.com/FreyaHolmer/
// Website & Documentation - https://acegikmo.com/shapes/

namespace Shapes {

	internal enum RenderPipeline {
		Legacy,
		URP,
		HDRP
	}

}