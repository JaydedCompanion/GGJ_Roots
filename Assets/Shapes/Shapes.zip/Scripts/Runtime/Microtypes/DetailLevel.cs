﻿// Shapes © Freya Holmér - https://twitter.com/FreyaHolmer/
// Website & Documentation - https://acegikmo.com/shapes/

namespace Shapes {

	public enum DetailLevel {
		Minimal,
		Low,
		Medium,
		High,
		Extreme
	}


}